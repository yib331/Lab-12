package BinaryTress;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			BinarySearchTree <StudentGPA> student = new BinarySearchTree();
			
			Scanner scan = new Scanner(new File("students.in"));
			
			int id; String name; double gpa; String ad;
			
			while(scan.hasNextLine()){
				String thisLine = scan.nextLine();
				Scanner line = new Scanner(thisLine);
				id = line.nextInt();
				name = line.next();
				gpa = line.nextDouble();
				
				//10 ABC 3.5 BOSS3
				//20 BCD 3.2
				
				if(line.hasNext()){
					ad = line.next();
					GraduateStudentGPA gradstudent = new GraduateStudentGPA(id, name, gpa, ad);
					student.insert(gradstudent);
				}
				else{
					StudentGPA undergradstudent = new StudentGPA(id, name, gpa);
					student.insert(undergradstudent);					
				}
				line.close();
				
		   
		    }
		    scan.close();
		    
		    TreeIterator<StudentGPA> sort = new TreeIterator<StudentGPA>(student);
			sort.setPostorder();
			
			for(StudentGPA s:student){
				System.out.println(s.toString());
			}		
		    
		    
		}
		catch(IOException e) { 
		    System.out.println("Caught IOException: "+ e.getMessage()); 
		}

	}
}

