package BinaryTress;
//package Heaps;

public class HeapException extends RuntimeException {

  public HeapException() {  
  }  // end default constructor

  public HeapException(String s) {
    super(s);
  }  // end constructor
}  // end HeapException
